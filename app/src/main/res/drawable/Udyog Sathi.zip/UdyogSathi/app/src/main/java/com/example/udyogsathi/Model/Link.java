package com.example.udyogsathi.Model;

import java.io.Serializable;

public class Link implements Serializable {
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String link;
}
